package view;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import controller.Features;
import controller.commands.Histogram;

/**
 * Class that implements the GUI View Interface.
 */
public class UIInterfaceImplementation extends JFrame implements UIInterface {

  private final Map<String, JButton> button = new HashMap<String, JButton>();
  private JPanel operationPanel;
  private JLabel imgLabel;
  private JLabel histogramLabel;

  /**
   * Constructor that sets up the GUI for use.
   */
  public UIInterfaceImplementation() {

    setSize(500, 500);
    setLocation(200, 200);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    this.setLayout(new FlowLayout());
    JPanel mainPanel = new JPanel();
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
    JScrollPane mainScrollPane = new JScrollPane(mainPanel);
    this.add(mainPanel);

    operationPanel = new JPanel();
    operationPanel.setBorder(BorderFactory.createTitledBorder("Image Operations"));
    operationPanel.setLayout(new GridLayout(2, 3));
    mainPanel.add(operationPanel);
    createButton();

    JPanel displayPanel = new JPanel();
    displayPanel.setLayout(new GridLayout(1, 2, 10, 10));
    mainPanel.add(displayPanel);

    JPanel histogramPanel = new JPanel();
    histogramPanel.setBorder(BorderFactory.createTitledBorder("Histogram"));
    histogramPanel.setLayout(new GridLayout(2, 2, 10, 10));
    histogramPanel.setPreferredSize(new Dimension(100, 100));
    displayPanel.add(histogramPanel);

    histogramLabel = new JLabel();
    JScrollPane histogramScroll = new JScrollPane(histogramLabel);
    histogramScroll.setPreferredSize(new Dimension(100, 100));
    histogramPanel.add(histogramScroll);

    JLabel labelss = new JLabel();
    JScrollPane histScroll = new JScrollPane(labelss);
    histScroll.setPreferredSize(new Dimension(100, 100));
    labelss.setIcon(new ImageIcon(new controller.commands.Histogram().generateHistogramLabel()));
    histogramPanel.add(histScroll);

    JPanel imgPanel = new JPanel();
    imgPanel.setBorder(BorderFactory.createTitledBorder("Image"));
    imgPanel.setLayout(new GridLayout(1, 0, 10, 10));
    displayPanel.add(imgPanel);

    imgLabel = new JLabel();
    JScrollPane imgScroll = new JScrollPane(imgLabel);
    imgScroll.setPreferredSize(new Dimension(600, 600));
    imgPanel.add(imgScroll);

    pack();
    setVisible(true);
  }

  /**
   * Creates buttons to be displayed in the GUI.
   *
   * @param name   Name of the button
   * @param action Action executed by the button
   */
  private void appendButton(String name, String action) {
    button.put(name, new JButton(name));
    button.get(name).setActionCommand(action);
    operationPanel.add(button.get(name));
  }

  @Override
  public void imgSet(BufferedImage image) throws IOException {
    imgLabel.setIcon(new ImageIcon(image));
    Histogram histogram = new Histogram();
    histogramLabel.setIcon(new ImageIcon(histogram.generateImageHistogram(image)));
  }

  /**
   * Defines the buttons inside the GUI.
   */
  private void createButton() {
    appendButton("Load", "Load File");
    appendButton("Save", "Save File");
    appendButton("Blur", "Blur Image");
    appendButton("Brighten", "Brighten Image");
    appendButton("Levels Adjustment", "Level Adjust Image");
    appendButton("Greyscale", "Greyscale Image");
    appendButton("Compress", "Compress Image");
    appendButton("Horizontal Flip", "Horizontal Flip");
    appendButton("Vertical Flip", "Vertical Flip");
    appendButton("Red Component", "Red Component of Image");
    appendButton("Green Component", "Green Component of Image");
    appendButton("Blue Component", "Blue Component of Image");
    appendButton("Color Correct", "Color Correct the Image");
    appendButton("Sepia", "Sepia Image");
    appendButton("Sharpen", "Sharpen Image");
    appendButton("Quit", "Quit");
  }

  @Override
  public String fetchFilePath(String option) {
    final JFileChooser choose = new JFileChooser(".");
    if (!option.equals("Save File")) {
      FileNameExtensionFilter filter =
              new FileNameExtensionFilter(
                      "JPG, JPEG, BMP, PNG, PPM Images", "jpg", "jpeg", "png", "ppm", "bmp");
      choose.setFileFilter(filter);
    }
    int retVal = choose.showOpenDialog(UIInterfaceImplementation.this);
    if (retVal == JFileChooser.APPROVE_OPTION) {
      File f = choose.getSelectedFile();
      return f.getAbsolutePath();
    }
    return "";
  }

  @Override
  public Integer inputBrighten() {
    JSlider slideBright = new JSlider(-255, 255, 0);
    slideBright.setLabelTable(slideBright.createStandardLabels(255));
    slideBright.setPaintLabels(true);
    slideBright.setPaintTicks(false);
    int result =
            JOptionPane.showConfirmDialog(
                    null, slideBright, "Brightness", JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
      return slideBright.getValue();
    } else {
      return 0;
    }
  }

  @Override
  public void addFeats(Features features) throws IOException {
    button
            .get("Load")
            .addActionListener(
                    s -> {
                      try {
                        features.loadImage();
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });
    button
            .get("Save")
            .addActionListener(
                    s -> {
                      try {
                        features.saveImage();
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });
    button
            .get("Blur")
            .addActionListener(
                    s -> {
                      JFrame brightnessPopUp = new JFrame("Pop-Up Window blur");
                      String input =
                              JOptionPane.showInputDialog(brightnessPopUp, "Enter the threshold value:");
                      double threshold = input.isEmpty() ? 0 : Double.parseDouble(input);
                      try {
                        features.blurImage(threshold);
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });
    button
            .get("Vertical Flip")
            .addActionListener(
                    s -> {
                      try {
                        features.verticalFlip();
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });
    button
            .get("Horizontal Flip")
            .addActionListener(
                    s -> {
                      try {
                        features.horizontalFlip();
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });
    button
            .get("Greyscale")
            .addActionListener(
                    s -> {
                      try {
                        features.greyscaleImage();
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });

    button
            .get("Compress")
            .addActionListener(
                    s -> {
                      JFrame brightnessPopUp = new JFrame("Pop-Up Window");
                      String input =
                              JOptionPane.showInputDialog(brightnessPopUp, "Enter the threshold value:");
                      int threshold = input.isEmpty() ? 0 : Integer.parseInt(input);
                      try {
                        features.compressImage(threshold);
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });

    button
            .get("Color Correct")
            .addActionListener(
                    s -> {
                      try {
                        features.colorCorrect();
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });

    button
            .get("Levels Adjustment")
            .addActionListener(
                    evt -> {
                      // this.split.setEnabled(true);
                      JFrame levelAdjustPopUp = new JFrame("Pop-Up window B/M/W");
                      String inputB = JOptionPane.showInputDialog(levelAdjustPopUp, "Enter the B");
                      String inputM = JOptionPane.showInputDialog(levelAdjustPopUp, "Enter the M");
                      String inputW = JOptionPane.showInputDialog(levelAdjustPopUp, "Enter the W");
                      String splitPercentage =
                              JOptionPane.showInputDialog(
                                      levelAdjustPopUp, "Enter the split value (is optional)");

                      int bValue = inputB.isEmpty() ? 0 : Integer.parseInt(inputB);
                      int mValue = inputM.isEmpty() ? 0 : Integer.parseInt(inputM);
                      int wValue = inputW.isEmpty() ? 0 : Integer.parseInt(inputW);
                      double split = splitPercentage.isEmpty() ? 100 : Double.parseDouble(splitPercentage);
                      try {
                        features.levelsAdjustment(bValue, mValue, wValue, split);
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }

                      if (split == 100) {
                        this.button.get("Save").setEnabled(true);
                      } else {
                        this.button.get("Save").setEnabled(false);
                      }
                    });
    button
            .get("Sepia")
            .addActionListener(
                    s -> {
                      JFrame brightnessPopUp = new JFrame("Pop-Up Window Sepia");
                      String input =
                              JOptionPane.showInputDialog(brightnessPopUp, "Enter the threshold value:");
                      double threshold = input.isEmpty() ? 0 : Double.parseDouble(input);
                      try {
                        features.sepia(threshold);
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });
    button
            .get("Sharpen")
            .addActionListener(
                    s -> {
                      try {
                        features.sharpen();
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });
    button
            .get("Brighten")
            .addActionListener(
                    s -> {
                      try {
                        features.brightenImage();
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });

    button
            .get("Red Component")
            .addActionListener(
                    s -> {
                      try {
                        features.redComp();
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });

    button
            .get("Green Component")
            .addActionListener(
                    s -> {
                      try {
                        features.greenComp();
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });

    button
            .get("Blue Component")
            .addActionListener(
                    s -> {
                      try {
                        features.blueComp();
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });

    button
            .get("Quit")
            .addActionListener(
                    s -> {
                      try {
                        features.quit();
                      } catch (IOException e) {
                        throw new RuntimeException(e);
                      }
                    });
  }

  @Override
  public void errNoImg() {
    JOptionPane.showMessageDialog(
            UIInterfaceImplementation.this,
            "No image has been loaded",
            "Error",
            JOptionPane.ERROR_MESSAGE);
  }

  @Override
  public void warnNewLoadSave() {
    JOptionPane.showMessageDialog(
            UIInterfaceImplementation.this,
            "Save the image if not saved.",
            "New Image Load",
            JOptionPane.WARNING_MESSAGE);
  }

  @Override
  public boolean quitGUI() {
    int result =
            JOptionPane.showOptionDialog(
                    null,
                    "Are you sure you want quit? Unsaved Changes will be deleted.",
                    "Quit Application",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    new String[]{"Yes", "Cancel"},
                    "Yes");

    return result == JOptionPane.YES_OPTION;
  }

  @Override
  public void errInvalidExt() {
    JOptionPane.showMessageDialog(
            UIInterfaceImplementation.this,
            "The Image File Format is not allowed",
            "Invalid Image File Format",
            JOptionPane.ERROR_MESSAGE);
  }
}
